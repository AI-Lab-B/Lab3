from collections import deque

def find_shortest_path(matrix):
    # Directions: Up, Down, Left, Right
    directions = [(-1, 0), (1, 0), (0, -1), (0, 1)]
    
    # Initialize starting and ending positions
    start = (1, 1)
    end = (4, 4)
    
    # Adjust for zero-based indexing
    start = (start[0] - 1, start[1] - 1)
    end = (end[0] - 1, end[1] - 1)
    
    rows, cols = len(matrix), len(matrix[0])
    queue = deque([(start, [start])])  # Store (position, path)
    visited = set()
    visited.add(start)
    
    while queue:
        (x, y), path = queue.popleft()
        
        if (x, y) == end:
            return [(p[0] + 1, p[1] + 1) for p in path]  # Convert back to 1-based indexing
        
        for dx, dy in directions:
            nx, ny = x + dx, y + dy
            if 0 <= nx < rows and 0 <= ny < cols and matrix[nx][ny] == 0 and (nx, ny) not in visited:
                queue.append(((nx, ny), path + [(nx, ny)]))
                visited.add((nx, ny))
    
    return None  # No path found

# Example usage:
matrix = [
    [0, 0, 0, 0, 0],
    [0, 1, 1, 1, 0],
    [0, 1, 0, 1, 0],
    [0, 1, 0, 0, 0],
    [0, 0, 0, 0, 0]
]

path = find_shortest_path(matrix)
print("Shortest Path:", path)