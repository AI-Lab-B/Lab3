from collections import deque
import time

def find_shortest_path(matrix):
    # Directions: Up, Down, Left, Right
    directions = [(-1, 0), (1, 0), (0, -1), (0, 1)]
    
    # Initialize starting and ending positions
    start = (1, 1)
    end = (4, 4)
    
    # Adjust for zero-based indexing
    start = (start[0] - 1, start[1] - 1)
    end = (end[0] - 1, end[1] - 1)
    
    rows, cols = len(matrix), len(matrix[0])
    queue = deque([(start, [start])])  # Store (position, path)
    visited = set()
    visited.add(start)
    
    while queue:
        (x, y), path = queue.popleft()
        
        if (x, y) == end:
            return [(p[0] + 1, p[1] + 1) for p in path]  # Convert back to 1-based indexing
        
        for dx, dy in directions:
            nx, ny = x + dx, y + dy
            if 0 <= nx < rows and 0 <= ny < cols and matrix[nx][ny] == 0 and (nx, ny) not in visited:
                queue.append(((nx, ny), path + [(nx, ny)]))
                visited.add((nx, ny))
    
    return None  # No path found

def state_to_tuple(state):
    """Convert a string state to a tuple representation."""
    return tuple(state)

def tuple_to_state(matrix):
    """Convert a tuple representation back to a string state."""
    return ''.join(matrix)

def get_moves(state):
    """Generate possible moves from the given state."""
    moves = []
    index = state.index('0')
    row, col = divmod(index, 3)
    
    directions = {
        'Up': (-1, 0), 'Down': (1, 0), 'Left': (0, -1), 'Right': (0, 1)
    }
    
    for move, (dr, dc) in directions.items():
        new_row, new_col = row + dr, col + dc
        if 0 <= new_row < 3 and 0 <= new_col < 3:
            new_index = new_row * 3 + new_col
            new_state = list(state)
            new_state[index], new_state[new_index] = new_state[new_index], new_state[index]
            moves.append((''.join(new_state), move))
    
    return moves

def dfs(start_state, goal_state):
    """Perform Depth-First Search (DFS) to find a solution path."""
    stack = [(start_state, [])]
    visited = set()
    
    while stack:
        state, path = stack.pop()
        
        if state == goal_state:
            return path
        
        if state not in visited:
            visited.add(state)
            for new_state, move in get_moves(state):
                stack.append((new_state, path + [move]))
    
    return None  # No solution found

def main():
    """Main function to take input and execute the DFS algorithm."""
    start_state = input("Enter start State: ")   
    goal_state = input("Enter goal State: ")
    
    start_tuple = state_to_tuple(start_state)   
    goal_tuple = state_to_tuple(goal_state)
    
    print("-----------------")   
    print("DFS Algorithm")   
    print("-----------------")
    
    start_time = time.time()   
    solution_path = dfs(start_tuple, goal_tuple)   
    end_time = time.time()
    
    if solution_path:
        print("Time taken:", end_time - start_time, "seconds")   
        print("Path Cost:", len(solution_path))   
        print("No of Nodes Visited:", len(solution_path) + 1)   
        print("Moves:", ' -> '.join(solution_path))
    else:
        print("No solution found.")

if __name__ == "__main__":   
    main()
