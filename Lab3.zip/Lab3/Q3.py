from collections import deque
import time

class Graph:
    def __init__(self, adjacency_list, heuristic):
        """Initializes the graph with an adjacency list and heuristic function."""
        self.adjacency_list = adjacency_list
        self.heuristic = heuristic
    
    def get_neighbors(self, node):
        """Returns the neighbors of a given node."""
        return self.adjacency_list.get(node, [])
    
    def a_star_algorithm(self, start_node, stop_node):
        """Implements the A* search algorithm to find the optimal path."""
        open_list = set([start_node])
        closed_list = set()
        
        g = {start_node: 0}  # Cost from start node to all other nodes
        parents = {start_node: None}  # Keeps track of paths
        
        while open_list:
            n = min(open_list, key=lambda x: g[x] + self.heuristic[x])
            
            if n == stop_node:
                path = []
                while n:
                    path.append(n)
                    n = parents[n]
                return path[::-1], g[stop_node]
            
            open_list.remove(n)
            closed_list.add(n)
            
            for (neighbor, cost) in self.get_neighbors(n):
                if neighbor in closed_list:
                    continue
                tentative_g = g[n] + cost
                
                if neighbor not in open_list:
                    open_list.add(neighbor)
                elif tentative_g >= g.get(neighbor, float('inf')):
                    continue
                
                parents[neighbor] = n
                g[neighbor] = tentative_g
        
        return None, float('inf')  # No path found

# Define the word graph as an adjacency list
adjacency_list = {
    "The": [("cat", 1), ("dog", 2)],
    "cat": [("runs", 1)],
    "dog": [("runs", 2)],
    "runs": [("fast", 1)],
    "fast": []
}

# Define heuristic function
heuristic = {
    "The": 4,
    "cat": 3,
    "dog": 3,
    "runs": 2,
    "fast": 1
}

graph = Graph(adjacency_list, heuristic)
path, cost = graph.a_star_algorithm("The", "fast")

if path:
    print("Sentence:", " ".join(path))
    print("Total cost:", cost)
else:
    print("No path found.")
